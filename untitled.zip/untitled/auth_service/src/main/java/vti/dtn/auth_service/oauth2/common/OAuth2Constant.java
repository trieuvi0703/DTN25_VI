package vti.dtn.auth_service.oauth2.common;

public class OAuth2Constant {
    public static final String GOOGLE = "google";
    public static final String FACEBOOK = "facebook";
    public static final String GITHUB = "github";

    public static final String ROLE_USER = "ROLE_USER";
}

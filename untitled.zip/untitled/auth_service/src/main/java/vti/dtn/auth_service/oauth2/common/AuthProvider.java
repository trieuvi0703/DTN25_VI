package vti.dtn.auth_service.oauth2.common;

public enum AuthProvider {
    local,
    facebook,
    google,
    github
}
